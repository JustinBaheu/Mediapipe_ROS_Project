// Auto-generated. Do not edit!

// (in-package sk_tracking.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Keypoint = require('./Keypoint.js');

//-----------------------------------------------------------

class Test2 {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Left_Hand_Key = null;
    }
    else {
      if (initObj.hasOwnProperty('Left_Hand_Key')) {
        this.Left_Hand_Key = initObj.Left_Hand_Key
      }
      else {
        this.Left_Hand_Key = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Test2
    // Serialize message field [Left_Hand_Key]
    // Serialize the length for message field [Left_Hand_Key]
    bufferOffset = _serializer.uint32(obj.Left_Hand_Key.length, buffer, bufferOffset);
    obj.Left_Hand_Key.forEach((val) => {
      bufferOffset = Keypoint.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Test2
    let len;
    let data = new Test2(null);
    // Deserialize message field [Left_Hand_Key]
    // Deserialize array length for message field [Left_Hand_Key]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.Left_Hand_Key = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.Left_Hand_Key[i] = Keypoint.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 32 * object.Left_Hand_Key.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sk_tracking/Test2';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bc953bf2af07ab7e401dbca444529ec0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    sk_tracking/Keypoint[] Left_Hand_Key
    
    ================================================================================
    MSG: sk_tracking/Keypoint
    float64 x
    float64 y
    float64 z
    float64 v
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Test2(null);
    if (msg.Left_Hand_Key !== undefined) {
      resolved.Left_Hand_Key = new Array(msg.Left_Hand_Key.length);
      for (let i = 0; i < resolved.Left_Hand_Key.length; ++i) {
        resolved.Left_Hand_Key[i] = Keypoint.Resolve(msg.Left_Hand_Key[i]);
      }
    }
    else {
      resolved.Left_Hand_Key = []
    }

    return resolved;
    }
};

module.exports = Test2;
