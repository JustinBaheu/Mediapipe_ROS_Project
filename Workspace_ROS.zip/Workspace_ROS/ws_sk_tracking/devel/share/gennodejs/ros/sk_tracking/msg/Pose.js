// Auto-generated. Do not edit!

// (in-package sk_tracking.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Pose {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Pose_Key = null;
    }
    else {
      if (initObj.hasOwnProperty('Pose_Key')) {
        this.Pose_Key = initObj.Pose_Key
      }
      else {
        this.Pose_Key = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Pose
    // Serialize message field [Pose_Key]
    bufferOffset = _arraySerializer.float64(obj.Pose_Key, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Pose
    let len;
    let data = new Pose(null);
    // Deserialize message field [Pose_Key]
    data.Pose_Key = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.Pose_Key.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sk_tracking/Pose';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6f89d51c36e4e277c81268261814bd38';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64[] Pose_Key
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Pose(null);
    if (msg.Pose_Key !== undefined) {
      resolved.Pose_Key = msg.Pose_Key;
    }
    else {
      resolved.Pose_Key = []
    }

    return resolved;
    }
};

module.exports = Pose;
