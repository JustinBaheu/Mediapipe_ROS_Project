// Auto-generated. Do not edit!

// (in-package sk_tracking.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Right_Hand {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Right_Hand_Key = null;
    }
    else {
      if (initObj.hasOwnProperty('Right_Hand_Key')) {
        this.Right_Hand_Key = initObj.Right_Hand_Key
      }
      else {
        this.Right_Hand_Key = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Right_Hand
    // Serialize message field [Right_Hand_Key]
    bufferOffset = _arraySerializer.float64(obj.Right_Hand_Key, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Right_Hand
    let len;
    let data = new Right_Hand(null);
    // Deserialize message field [Right_Hand_Key]
    data.Right_Hand_Key = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.Right_Hand_Key.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sk_tracking/Right_Hand';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c6a9bfaea3d4bf08cf8bd46607e6a1ac';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64[] Right_Hand_Key
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Right_Hand(null);
    if (msg.Right_Hand_Key !== undefined) {
      resolved.Right_Hand_Key = msg.Right_Hand_Key;
    }
    else {
      resolved.Right_Hand_Key = []
    }

    return resolved;
    }
};

module.exports = Right_Hand;
