// Auto-generated. Do not edit!

// (in-package sk_tracking.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Holistic {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.H_Key = null;
      this.Name = null;
    }
    else {
      if (initObj.hasOwnProperty('H_Key')) {
        this.H_Key = initObj.H_Key
      }
      else {
        this.H_Key = [];
      }
      if (initObj.hasOwnProperty('Name')) {
        this.Name = initObj.Name
      }
      else {
        this.Name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Holistic
    // Serialize message field [H_Key]
    bufferOffset = _arraySerializer.float64(obj.H_Key, buffer, bufferOffset, null);
    // Serialize message field [Name]
    bufferOffset = _serializer.string(obj.Name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Holistic
    let len;
    let data = new Holistic(null);
    // Deserialize message field [H_Key]
    data.H_Key = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Name]
    data.Name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.H_Key.length;
    length += _getByteLength(object.Name);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sk_tracking/Holistic';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9670619350acb529bee060ccaf5522a7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64[] H_Key
    string Name
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Holistic(null);
    if (msg.H_Key !== undefined) {
      resolved.H_Key = msg.H_Key;
    }
    else {
      resolved.H_Key = []
    }

    if (msg.Name !== undefined) {
      resolved.Name = msg.Name;
    }
    else {
      resolved.Name = ''
    }

    return resolved;
    }
};

module.exports = Holistic;
