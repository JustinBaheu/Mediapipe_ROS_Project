
"use strict";

let Face = require('./Face.js');
let Holistic = require('./Holistic.js');
let Pose = require('./Pose.js');
let Right_Hand = require('./Right_Hand.js');
let Keypoint = require('./Keypoint.js');
let Test2 = require('./Test2.js');
let test = require('./test.js');
let Left_Hand = require('./Left_Hand.js');

module.exports = {
  Face: Face,
  Holistic: Holistic,
  Pose: Pose,
  Right_Hand: Right_Hand,
  Keypoint: Keypoint,
  Test2: Test2,
  test: test,
  Left_Hand: Left_Hand,
};
